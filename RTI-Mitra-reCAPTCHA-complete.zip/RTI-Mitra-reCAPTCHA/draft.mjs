export function makeDraft(fields) {
  const v = id => fields[id] || '';
  const today = new Date().toLocaleDateString('en-IN', {day:'numeric', month:'long', year:'numeric'});
  const period = v('dPer') ? ' for the period ' + v('dPer') : '';
  const draft =
`To,
The Public Information Officer,
${v('dDept')}

Date: ${today}

Subject: Request for information under the Right to Information Act, 2005 - ${v('dSub')}

Sir/Madam,

Under Section 6(1) of the Right to Information Act, 2005, I request the following information${period}:

${v('dInfo')}

[Add your payment details or applicable fee-exemption details before submission.] If any part of this request belongs to another public authority, please transfer it under Section 6(3) of the Act and inform me.

Please send the information to the address below.

Yours faithfully,
${v('dName')}
${v('dAddr')}`;

return draft;
}
