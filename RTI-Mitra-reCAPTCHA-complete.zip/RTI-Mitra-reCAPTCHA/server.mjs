import http from 'node:http';
import {readFile} from 'node:fs/promises';
import {makeDraft} from './draft.mjs';
const siteKey=process.env.RECAPTCHA_SITE_KEY || '';
const secret=process.env.RECAPTCHA_SECRET_KEY || '';
const hosts=(process.env.RECAPTCHA_ALLOWED_HOSTNAMES || 'localhost').split(',').map(s=>s.trim().toLowerCase()).filter(Boolean);
const configured=Boolean(siteKey && secret && !siteKey.startsWith('YOUR_') && !secret.startsWith('YOUR_'));
const page=await readFile(new URL('./index.html',import.meta.url));
export function validVerification(data) {
  const age=Date.now()-Date.parse(data.challenge_ts);
  return data.success===true && !data['error-codes']?.length && hosts.includes(String(data.hostname).toLowerCase()) && Number.isFinite(age) && age>=-30000 && age<=120000;
}
const server=http.createServer(async (req,res)=>{
  const json=(status,data)=>{res.writeHead(status,{'Content-Type':'application/json','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(data));};
  const path=new URL(req.url,'http://localhost').pathname;
  if(req.method==='GET' && (path==='/' || path==='/index.html')){res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','X-Content-Type-Options':'nosniff','Referrer-Policy':'strict-origin-when-cross-origin'});res.end(page);return;}
  if(req.method==='GET' && path==='/api/recaptcha-config'){json(configured?200:503,configured?{siteKey}:{error:'Configure the server reCAPTCHA keys first.'});return;}
  if(req.method!=='POST' || !['/api/draft','/api/verify'].includes(path)){json(404,{error:'Not found'});return;}
  if(!configured){json(503,{error:'Verification is not configured. Contact the site owner.'});return;}
  if(!/^application\/json(?:;|$)/i.test(req.headers['content-type']||'')){json(415,{error:'JSON required'});return;}
  try {
    let raw='';
    for await(const chunk of req){raw+=chunk;if(Buffer.byteLength(raw)>32768){json(413,{error:'Request too large'});return;}}
    let input;try{input=JSON.parse(raw);}catch{json(400,{error:'Invalid JSON'});return;}
    if(!input || typeof input.token!=='string' || !input.token || input.token.length>8192){json(400,{error:'Complete reCAPTCHA before submitting.'});return;}
    const fields=input.fields;
    if(path==='/api/draft' && (!fields || ['dName','dAddr','dDept','dSub','dInfo'].some(k=>typeof fields[k]!=='string'||!fields[k].trim()||fields[k].length>8000) || (fields.dPer!==undefined && (typeof fields.dPer!=='string'||fields.dPer.length>1000)))){json(400,{error:'Please complete all required draft fields.'});return;}
    const google=await fetch('https://www.google.com/recaptcha/api/siteverify',{method:'POST',body:new URLSearchParams({secret,response:input.token}),signal:AbortSignal.timeout(10000)});
    if(!google.ok)throw new Error('upstream');
    const verdict=await google.json();
    if(!validVerification(verdict)){json(403,{error:'Verification was rejected or expired. Please complete a new check.'});return;}
    json(200,path==='/api/draft'?{ok:true,draft:makeDraft(fields)}:{ok:true});
  } catch {json(503,{error:'Verification service is unavailable. Please try again.'});}
});
server.requestTimeout=20000;
server.headersTimeout=15000;
if(process.env.NODE_ENV!=='test') server.listen(Number(process.env.PORT || 3000),'0.0.0.0',()=>console.log('RTI Mitra: http://localhost:'+(process.env.PORT||3000)+(configured?'':' (add reCAPTCHA keys in .env to activate verification)')));
export {server};
