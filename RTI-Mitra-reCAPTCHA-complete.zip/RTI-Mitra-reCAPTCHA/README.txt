RTI MITRA — GOOGLE reCAPTCHA SETUP

This package preserves your website design and adds Google reCAPTCHA v2 checkbox verification to Create my draft and Save application.
Activation requires your own Google keys and a running backend. No fake or always-pass test keys are included.

WINDOWS QUICK START
1. Install Node.js 22 or newer from https://nodejs.org/.
2. Extract this entire ZIP.
3. Register a reCAPTCHA v2 "I'm not a robot" checkbox key at:
   https://www.google.com/recaptcha/admin/create
   Add localhost for local use and your actual domain for deployment.
   Use a key with a corresponding secret compatible with Google's SiteVerify API.
4. Copy .env.example to .env. Open .env in Notepad.
   Set RECAPTCHA_SITE_KEY to your public site key.
   Set RECAPTCHA_SECRET_KEY to your secret key. NEVER place the secret in HTML or share it.
   Set RECAPTCHA_ALLOWED_HOSTNAMES to exact allowed hostnames, comma separated,
   e.g. localhost,example.com,www.example.com (no https:// or paths).
5. Double-click START-WINDOWS.bat, then open http://localhost:3000 in Chrome.
   Alternatively: node --env-file=.env server.mjs
   Keep the terminal open while using the website.

DEPLOYMENT
Run this package on a Node.js host with HTTPS and set the same environment variables there. Register the deployed domain in Google reCAPTCHA and in RECAPTCHA_ALLOWED_HOSTNAMES. Do not upload .env publicly. Static-only hosting and file:/// URLs cannot run the verification backend. Add hosting-level request rate limits for a public deployment.

BEHAVIOUR AND PRIVACY
The backend sends only the reCAPTCHA response token and secret to Google SiteVerify. Draft details go to this server to generate the draft after verification; this implementation does not store or log them. Google's client widget separately collects data under Google's policies, linked by each form.
Every submission consumes a token. Expired, reused, invalid, unexpected-host, provider-error, and missing responses fail closed. Tokens expire after two minutes. The secret is never returned to browsers; only index.html and the public configuration endpoint are served.
The tracker remains browser-local storage. Its UI requires verification to add an entry, but a user controlling their browser can edit their own local data. This is not an account or access-control system. Public information and FAQs remain accessible. reCAPTCHA reduces automated abuse; it cannot guarantee every visitor is human.

VALIDATION
JavaScript syntax and backend failure/success paths were checked with mocked Google responses. A real Google challenge still needs your registered keys and domain; it was not tested live.

Google documentation:
https://developers.google.com/recaptcha/docs/display
https://developers.google.com/recaptcha/docs/verify
